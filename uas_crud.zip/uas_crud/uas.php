<?php $koneksi = mysqli_connect("localhost","root","","uas_nama"); ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>AD HASAN</title>
	<link rel="stylesheet" href="style.css">
</head>
<body>
	<div class="container-fluid mt-5">
		<div class="row">
			<div class="col-md-12">
				<table>
					<tr>
						<td width="100">NIM</td>
						<td width="10">:</td>
						<td>181902001</td>
					</tr>
					<tr>
						<br>
						<div class="row">
							<div class="col-md-5">
								<div class="card">
									<div class="card-header">
										<td>NAMA</td>
										<td>:</td>
										<td>AD HASAN</td>
									</tr>
								</table>
							</div>
						</div>

						<br>
						<div class="row">
							<div class="col-md-5">
								<?php  if (isset($_GET["page"])) : ?>
									<?php if($_GET["page"] == "home") : ?>
										<div class="card">
											<div class="card-header">
												<h5>Input Barang Baru</h5>
											</div>
											<div class="card-body">
												<form action="" method="post">
													<div class="form-group">
														<?php  
														if (isset($_POST["simpan"])) {
															$kode_barang = htmlspecialchars(addslashes($_POST["kode"]));
															$nama_barang = htmlspecialchars(addslashes($_POST["nama"]));
															$harga_barang = htmlspecialchars(addslashes($_POST["harga"]));
															if (empty($kode_barang) AND empty($nama_barang) AND empty($harga_barang)) {
																echo "<div class='alert alert-danger text-center'>Semua kolom harus diisi !</div>";
															} elseif (empty($nama_barang)) {
																echo "<div class='alert alert-danger text-center'><b>Nama Barang</b> tidak boleh kosong !</div>";
															} elseif (empty($harga_barang)) {
																echo "<div class='alert alert-danger text-center'><b>Harga Barang</b> tidak boleh kosong !</div>";
															} elseif (empty($kode_barang)) {
																echo "<div class='alert alert-danger text-center'><b>Kode Barang</b> tidak boleh kosong !</div>";
															} 
															$result = $koneksi->query("SELECT * FROM barang_nim WHERE kode_barang = '$kode_barang'");
															if (mysqli_num_rows($result) == 1) {
																echo "<div class='alert alert-danger text-center'><b>Kode Barang $kode_barang</b> sudah ada !</div>";
															} if(!empty($kode_barang) AND !empty($nama_barang) AND !empty($harga_barang) AND mysqli_num_rows($result) != 1) {
																$query = $koneksi->query("INSERT INTO barang_181902001 VALUES ('','$kode_barang','$nama_barang','$harga_barang')");
																echo "<div class='alert alert-success text-center'>Barang baru berhasil ditambahkan !</div>";
															}
														}
														?>
													</div>
													<div class="form-group">
														<label>Kode Barang</label>
														<input type="text" name="kode_barang" class="form-control">
													</div>
													<div class="form-group">
														<label>Nama Barang</label>
														<input type="text" name="nama_barang" class="form-control">
													</div>
													<div class="form-group">
														<label>Harga Barang</label>
														<input type="number" name="harga_barang" class="form-control">
													</div>
													<div class="form-group">
														<button type="submit" name="simpan" class="btn btn-sm btn-info">Simpan</button>
														<button type="reset" class="btn btn-sm btn-secondary">Batal</button>
													</div>
												</form>
											</div>
										</div>
									<?php elseif($_GET["page"] == "ubah") : ?>
										<div class="card">
											<div class="card-header">
												<h5>Ubah Barang</h5>
											</div>
											<?php  
											$perbarui = $koneksi->query("SELECT * FROM barang_nim WHERE id = $_GET[barang]");
											$baru = $perbarui->fetch_assoc();
											?>
											<div class="card-body">
												<form action="" method="post">
													<div class="form-group">
														<?php  
														if (isset($_POST["simpan"])) {
															$id = htmlspecialchars(addslashes($_POST["id"]));
															$kode_barang = htmlspecialchars(addslashes($_POST["kode_barang"]));
															$nama_barang = htmlspecialchars(addslashes($_POST["nama_barang"]));
															$harga_barang = htmlspecialchars(addslashes($_POST["harga_barang"]));
															if (empty($kode_barang) AND empty($nama_barang) AND empty($harga_barang)) {
																echo "<div class='alert alert-danger text-center'>Semua kolom harus diisi !</div>";
															} elseif (empty($nama_barang)) {
																echo "<div class='alert alert-danger text-center'><b>Nama Barang</b> tidak boleh kosong !</div>";
															} elseif (empty($harga_barang)) {
																echo "<div class='alert alert-danger text-center'><b>Harga Barang</b> tidak boleh kosong !</div>";
															} elseif (empty($kode_barang)) {
																echo "<div class='alert alert-danger text-center'><b>Kode Barang</b> tidak boleh kosong !</div>";
															} if(!empty($kode_barang) AND !empty($nama_barang) AND !empty($harga_barang)) {
																$query = $koneksi->query("UPDATE barang_nim SET 
																	id = $id,
																	kode_barang = '$kode_barang',
																	nama_barang = '$nama_barang',
																	harga_barang = '$harga_barang'
																	WHERE id = $id");
																echo "<div class='alert alert-success text-center'>Barang berhasil diperbarui !</div>";
																echo "<meta http-equiv='refresh' content='1;url=index.php'>";
															}
														}
														?>
													</div>
													<div class="form-group">
														<input type="hidden" name="id" value="<?php echo $baru["id"]; ?>">
														<label>Kode Barang</label>
														<input type="text" name="kode_barang" readonly value="<?php echo $baru["kode_barang"]; ?>" class="form-control">
													</div>
													<div class="form-group">
														<label>Nama Barang</label>
														<input type="text" name="nama_barang" value="<?php echo $baru["nama_barang"]; ?>" class="form-control">
													</div>
													<div class="form-group">
														<label>Harga Barang</label>
														<input type="number" name="harga_barang" value="<?php echo $baru["harga_barang"]; ?>" class="form-control">
													</div>
													<div class="form-group">
														<button type="submit" name="simpan" class="btn btn-sm btn-info">Simpan</button>
														<a href="index.php" class="btn btn-sm btn-default">Kembali</a>
													</div>
												</form>
											</div>
										</div>
									<?php elseif($_GET["page"] == "hapus") : ?>
										<?php  
										$query = $koneksi->query("DELETE FROM barang_nim WHERE id = $_GET[barang]");
										echo "<script>document.location='index.php'</script>";
										?>
									<?php endif; ?>
								<?php else : ?>
									<div class="card">
										<div class="card-header">
											<h5>Input Barang Baru</h5>
										</div>
										<div class="card-body">
											<form action="" method="post">
												<div class="form-group">
													<?php  
													if (isset($_POST["simpan"])) {
														$kode_barang = htmlspecialchars(addslashes($_POST["kode_barang"]));
														$nama_barang = htmlspecialchars(addslashes($_POST["nama_barang"]));
														$harga_barang = htmlspecialchars(addslashes($_POST["harga_barang"]));
														if (empty($kode_barang) AND empty($nama_barang) AND empty($harga_barang)) {
															echo "<div class='alert alert-danger text-center'>Semua kolom harus diisi !</div>";
														} elseif (empty($nama_barang)) {
															echo "<div class='alert alert-danger text-center'><b>Nama Barang</b> tidak boleh kosong !</div>";
														} elseif (empty($harga_barang)) {
															echo "<div class='alert alert-danger text-center'><b>Harga Barang</b> tidak boleh kosong !</div>";
														} elseif (empty($kode_barang)) {
															echo "<div class='alert alert-danger text-center'><b>Kode Barang</b> tidak boleh kosong !</div>";
														} 
														$result = $koneksi->query("SELECT * FROM barang_nim WHERE kode_barang = '$kode_barang'");
														if (mysqli_num_rows($result) == 1) {
															echo "<div class='alert alert-danger text-center'><b>Kode Barang $kode_barang</b> sudah ada !</div>";
														} if(!empty($kode_barang) AND !empty($nama_barang) AND !empty($harga_barang) AND mysqli_num_rows($result) != 1) {
															$query = $koneksi->query("INSERT INTO barang_181902001 VALUES ('','$kode_barang','$nama_barang','$harga_barang')");
															echo "<div class='alert alert-success text-center'>Barang baru berhasil ditambahkan !</div>";
														}
													}
													?>
												</div>
												<div class="form-group">
													<label>Kode Barang</label>
													<input type="text" name="kode_barang" class="form-control">
												</div>
												<div class="form-group">
													<label>Nama Barang</label>
													<input type="text" name="nama_barang" class="form-control">
												</div>
												<div class="form-group">
													<label>Harga Barang</label>
													<input type="number" name="harga_barang" class="form-control">
												</div>
												<div class="form-group">
													<button type="submit" name="simpan" class="btn btn-sm btn-info">Simpan</button>
													<button type="reset" class="btn btn-sm btn-secondary">Batal</button>
												</div>
											</form>
										</div>
									</div>
								<?php endif; ?>
							</div>
							<div class="col-md-7">
								<div class="card">
									<div class="card-header">
										<h5>Data Barang</h5>
									</div>
									<div class="card-body">
										<table class="table table-bordered table-hover table-striped">
											<thead>
												<tr>
													<th>No</th>
													<th>Kode Barang</th>
													<th>Nama Barang</th>
													<th>Harga</th>
													<th>Aksi</th>
												</tr>
											</thead>
											<tbody>
												<?php  
												$no = 1;
												$query = $koneksi->query("SELECT * FROM barang_nim ORDER BY kode_barang ASC");
												while($data = $query->fetch_assoc()) {
													?>
													vardump('$query');
													<tr>
														<td><?php echo $no++; ?></td>
														<td><?php echo $data["kode_barang"]; ?></td>
														<td><?php echo $data["nama_barang"]; ?></td>
														<td>Rp. <?php echo number_format($data["harga_barang"]); ?></td>
														<td>
															<a href="?page=ubah&barang=<?php echo $data["id"]; ?>" class="btn btn-sm btn-primary">Ubah</a>
															<a href="?page=hapus&barang=<?php echo $data["id"]; ?>" onClick="return confirm('Apakah anda yakin ingin menghapus barang ini ?')" class="btn btn-sm btn-danger">Hapus</a>
														</td>
													</tr>
												<?php } ?>
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
						<br><br><br><br><br>
						<div class="row">
							<div class="col-md-12">
								<div class="text-center">
									<small>&copy; 2020 AD HASAN</small>
								</div>
							</div>
						</div>
					</div>
				</body>
				</html>
